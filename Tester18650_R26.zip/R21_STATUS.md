# R21 NodeMCU PCB mapping

Numerirano svih 30 padova prema priloženoj NodeMCU ESP8266 slici (USB dolje u referenci), dodijeljene poznate mreže A0, D1, D4, D5, 3V3 i GND.

**VAŽNO:** donji lijevi pad ostavljen kao `VIN_OR_VU_UNVERIFIED` bez mreže jer pinout slika prikazuje VIN, a korisnik potvrđuje da njegov VU (ne VIN) daje 5 V. Nije sigurno preslikati VU na taj pad. INA219 nije mapiran; vodovi nisu trasirani. Projekt NIJE spreman za izradu.

- A0: x=-13.97, y=-17.78, ADC_A0
- RSV1: x=-13.97, y=-15.24, unassigned
- RSV2: x=-13.97, y=-12.7, unassigned
- SD3: x=-13.97, y=-10.16, unassigned
- SD2: x=-13.97, y=-7.62, unassigned
- SD1: x=-13.97, y=-5.08, unassigned
- CMD: x=-13.97, y=-2.54, unassigned
- CLK: x=-13.97, y=2.54, unassigned
- GND_L1: x=-13.97, y=5.08, BAT_MINUS_GND
- EN: x=-13.97, y=10.16, unassigned
- RST: x=-13.97, y=12.7, unassigned
- VIN_OR_VU_UNVERIFIED: x=-13.97, y=17.78, unassigned
- D1: x=13.97, y=-15.24, I2C_SCL
- D2: x=13.97, y=-12.7, unassigned
- D3: x=13.97, y=-10.16, unassigned
- D4: x=13.97, y=-7.62, I2C_SDA
- GND_R1: x=13.97, y=-2.54, BAT_MINUS_GND
- D5: x=13.97, y=0.0, GPIO14_D5
- D6: x=13.97, y=2.54, unassigned
- D7: x=13.97, y=5.08, unassigned
- D8: x=13.97, y=7.62, unassigned
- RX: x=13.97, y=10.16, unassigned
- TX: x=13.97, y=12.7, unassigned
- GND_R2: x=13.97, y=15.24, BAT_MINUS_GND
- SD0: x=-13.97, y=0.0, unassigned
- 3V3_L: x=-13.97, y=7.62, 3V3
- GND_L2: x=-13.97, y=15.24, BAT_MINUS_GND
- 3V3_R2: x=13.97, y=17.78, 3V3
- D0: x=13.97, y=-17.78, unassigned
- 3V3_R1: x=13.97, y=-5.08, 3V3
