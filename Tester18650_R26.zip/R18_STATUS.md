# R18 — stvarne PCB mreže (nastavak R17)

Promijenjeno **6 padova**: R1/R2 oba kraja opterećenja i A1/A2 zavojnice releja. Sačuvane su postojeće koordinate, bušenja i položaji svih footprintova. Dodane su mreže `LOAD_RETURN` i `RELAY_COIL_PLUS`.

## Važno: nije proizvodni PCB
- **Nema trasiranih vodova.** R18 samo pridružuje logičke mreže postojećim padovima.
- **NodeMCU J1:** 24 pada imaju prazne brojeve; šest numeriranih ne može se automatski poistovjetiti s VU/D5/D4/D1/A0. Potrebna je ispravna numeracija footprinta prema stvarnom modulu, bez pomicanja rupa.
- **INA219 J2:** numeracija 1–6 postoji, ali mapiranje IN+/IN−/VCC/GND/SDA/SCL prema geometriji footprinta treba provjeriti.
- **D1 i R5:** nisu prisutni kao footprintovi na ovoj referentnoj PCB datoteci. Ne smije se izdati Gerber bez njih ili bez izričitog dokumentiranja da su montirani izvan pločice.
- **R3/R4:** prisutni su, ali njihovi stvarni otpori i padovi prema A0 nisu dokazani, pa ih R18 nije nasumično povezao.
- **K1:** A1 postavljen na `RELAY_COIL_PLUS`, A2 na `RELAY_COIL_LOW`. Zavojnica nije polarizirana; polaritet diode mora ostati katoda na plusu.
- **C3209:** zadržano mapiranje korisnika: 1=GND, 2=RELAY_COIL_LOW, 3=RELAY_BASE.
- **ERC R16:** korisnik potvrdio `0 violations`; za R18 PCB DRC nije izvršen (KiCad CLI nije dostupan ovdje).

Ovaj paket je namjerno označen kao radni, bez lažne tvrdnje da je PCB gotov.
