# Tester 18650 — R12 provjera postojećeg PCB-a

Ovo je provjera postojeće KiCad PCB datoteke, a ne gotov proizvodni PCB.

## Što je utvrđeno iz same datoteke

- K1 footprint `RT314006_16A_8PIN_5MM_KICAD_REFERENCE`: osam fizičkih padova označenih `11`, `11`, `12`, `12`, `14`, `14`, `A1`, `A2`. Duplicirane oznake su namjerne i odgovaraju dvostrukim izvodima kontakata. **Ne treba tražiti novu fotografiju releja.**
- Q1 footprint `C3209_CROP_GRID_UNMAPPED`: tri rupe na 2,54 mm s privremenim oznakama `TOP_E_REF`, `MID_C_REF`, `BOT_B_REF`. Te oznake nisu dokaz da je to stvarni redoslijed E/C/B. **Ne smije se povezati na slijepo.**
- BAT priključci postoje kao zasebni THT padovi (`TestPoint...`), a držač baterije je mehanička referenca bez padova. To **ne znači** da priključci baterije nedostaju: žice su zalemljene na zasebne padove. Položaje ne mijenjati.
- Postojeća shema R11 i fizički raspored PCB-a nisu usklađeni referencama, brojevima padova i mrežama. KiCad ERC sheme nije zamjena za PCB DRC.

## Električne mreže koje se mogu definirati funkcionalno

- `BAT_PLUS`: pozitivni priključak ćelije, zajednički COM kontakt releja i gornji kraj naponskog djelitelja.
- `LOAD_PLUS`: NO kontakt releja i oba otpornika od 22 Ω / 5 W.
- `LOAD_RETURN`: drugi krajevi otpornika opterećenja i INA219 IN+ (funkcionalni model; potvrditi u odnosu na fizički uređaj).
- `BAT_MINUS_GND`: negativni priključak ćelije, INA219 IN− i NodeMCU GND (korisnik izmjerio).
- `RELAY_COIL_PLUS`: NodeMCU VU, zavojnica releja, katoda zaštitne diode.
- `RELAY_COIL_LOW`: druga strana zavojnice, kolektor tranzistora, anoda diode.
- `RELAY_BASE`: izlaz GPIO14 preko baznog otpornika na bazu tranzistora.
- `I2C_SDA`: GPIO2 → INA219 SDA; `I2C_SCL`: GPIO5 → INA219 SCL.

## Blokade za proizvodni PCB

1. Pinout C3209 treba utvrditi iz pouzdanog datasheeta za točno kućište i orijentaciju, pa tek tada mapirati tri fizička pada.
2. Treba provjeriti točne funkcije i redoslijed fizičkih padova NodeMCU i INA219 footprintova prije uvođenja mreža.
3. Treba dovršiti shemu s ispravnim brojevima pinova i povezati je s PCB-om kroz KiCad `Update PCB from Schematic`.
4. Nakon toga napraviti trasiranje, DRC i provjeru stvarnih razmaka, osobito oko otpornika 5 W i relejnih kontakata.

**Status:** pregledano i evidentirano; PCB nije spreman za izradu. Ne mijenjati postojeće fizičke položaje baterijskih padova i tranzistora.
