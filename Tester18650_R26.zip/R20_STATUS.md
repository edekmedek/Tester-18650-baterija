# R20 — stvarne izmjene PCB datoteke

Dodana su dva ranije nedostajuća THT footprinta: **D1** (katoda = RELAY_COIL_PLUS, anoda = RELAY_COIL_LOW) i **R5** (GPIO14_D5 → RELAY_BASE, 1 kΩ privremena vrijednost).

**Namjerno su postavljeni izvan pločice na x=200 mm** kao radna pozicija, da se ne izmišlja fizički raspored ili ne pregaze postojeće rupe. Ovo nije proizvodni PCB.

Nisu promijenjeni položaji postojećih komponenti. NodeMCU i INA219 mapiranje nije riješeno; vodovi nisu trasirani. DRC nije pokrenut. Sljedeće je usklađivanje padova sa stvarnim pinovima, pa raspored D1/R5 unutar pločice i trasiranje.
