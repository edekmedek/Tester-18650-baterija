# R24 — INA219 pad mapping

Prema fotografiji stvarnog INA219 breakout modula: kontrolni red SCL, SDA, VCC, GND; strujni priključci IN− lijevo, IN+ desno.

U PCB-u (J2): pad 2=SCL/I2C_SCL, pad 1=SDA/I2C_SDA, pad 3=VCC/3V3, pad 4=GND/BAT_MINUS_GND, padovi 5=IN+/LOAD_RETURN, padovi 6=IN−/BAT_MINUS_GND.

**Važno:** raspored IN+/IN− izveden je iz rotacije fotografije u horizontalni footprint, ali nije neovisno potvrđen usporedbom točaka lemljenja na PCB-u. Prije proizvodnje obavezna vizualna provjera orijentacije.

Ova revizija dodaje 8 mapiranja na INA219; ne dodaje vodove i nije proizvodna pločica. Ostaje fizičko VU napajanje NodeMCU-a koje nije prikazano kao zaseban pad na korištenom footprintu, te smještaj D1/R5.
